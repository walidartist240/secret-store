
// Simple cart using localStorage. Sends order summary to WhatsApp on checkout.
const sampleProducts = [
  {id: 'p1', name: 'طقم لانجري أنيق', price: 450, section: 'lingerie', img: 'assets/logo.jpg'},
  {id: 'p2', name: 'برا حريري', price: 320, section: 'bra', img: 'assets/logo.jpg'},
  {id: 'p3', name: 'اندر مريح', price: 120, section: 'underwear', img: 'assets/logo.jpg'},
  {id: 'p4', name: 'لعبة زوجية صغيرة', price: 250, section: 'toys', img: 'assets/logo.jpg'},
  {id: 'p5', name: 'بيجامة قطنية', price: 380, section: 'pajamas', img: 'assets/logo.jpg'}
];

const sectionsMap = {
  'lingerie': 'لانجرى',
  'bra': 'برا',
  'underwear': 'اندر',
  'toys': 'ألعاب زوجية',
  'pajamas': 'بيجامة'
};

function qs(sel){return document.querySelector(sel)}
function qsa(sel){return Array.from(document.querySelectorAll(sel))}

function formatPrice(p){ return p + ' جنيه' }

// render products
function renderAll(){
  sampleProducts.forEach(p => {
    const listId = p.section + '-list';
    const container = qs('#' + listId);
    if(!container) return;
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <img src="${p.img}" alt="${p.name}">
      <h4>${p.name}</h4>
      <p>${formatPrice(p.price)}</p>
      <div class="actions">
        <button class="btn" data-add="${p.id}">أضف للسلة</button>
        <a class="btn" href="https://wa.me/201555551102?text=${encodeURIComponent(p.name + ' - أريد استعلام السعر')}">استعلام</a>
      </div>
    `;
    container.appendChild(card);
  });
}

renderAll();

// cart handling
const CART_KEY = 'secret_store_cart';
function getCart(){ return JSON.parse(localStorage.getItem(CART_KEY) || '[]') }
function saveCart(c){ localStorage.setItem(CART_KEY, JSON.stringify(c)); updateCartCount(); }

function addToCart(id){
  const prod = sampleProducts.find(p=>p.id===id);
  if(!prod) return;
  const cart = getCart();
  const exists = cart.find(i=>i.id===id);
  if(exists) exists.qty++;
  else cart.push({id:prod.id,name:prod.name,price:prod.price,img:prod.img,qty:1});
  saveCart(cart);
  alert('تم إضافة المنتج للسلة');
}

function updateCartCount(){
  const cart = getCart();
  const count = cart.reduce((s,i)=>s+i.qty,0);
  qs('#cart-count').innerText = count;
}

document.addEventListener('click', e=>{
  const add = e.target.closest('[data-add]');
  if(add){ addToCart(add.getAttribute('data-add')); return; }
  if(e.target.id === 'cart-btn'){ openCart(); }
  if(e.target.id === 'close-cart'){ closeCart(); }
  if(e.target.id === 'clear-cart'){ clearCart(); }
});

function openCart(){
  const modal = qs('#cart-modal');
  const items = qs('#cart-items');
  items.innerHTML = '';
  const cart = getCart();
  if(cart.length===0){ items.innerHTML = '<p class="muted">السلة فارغة</p>'; qs('#cart-total').innerText = '0'; modal.setAttribute('aria-hidden','false'); return; }
  cart.forEach(it=>{
    const div = document.createElement('div');
    div.className='cart-item';
    div.innerHTML = `
      <img src="${it.img}" alt="${it.name}">
      <div class="info">
        <div>${it.name}</div>
        <div class="muted">${formatPrice(it.price)} × ${it.qty}</div>
      </div>
      <div class="controls">
        <button class="btn" data-inc="${it.id}">+</button>
        <button class="btn" data-dec="${it.id}">-</button>
      </div>
    `;
    items.appendChild(div);
  });
  qs('#cart-total').innerText = cart.reduce((s,i)=>s+i.price*i.qty,0);
  modal.setAttribute('aria-hidden','false');
}

// cart quantity controls in modal
document.getElementById('cart-items').addEventListener('click', e=>{
  const inc = e.target.closest('[data-inc]');
  const dec = e.target.closest('[data-dec]');
  if(inc){ changeQty(inc.getAttribute('data-inc'), 1); openCart(); }
  if(dec){ changeQty(dec.getAttribute('data-dec'), -1); openCart(); }
});

function changeQty(id, delta){
  const cart = getCart();
  const it = cart.find(i=>i.id===id);
  if(!it) return;
  it.qty += delta;
  if(it.qty<=0){ const idx = cart.findIndex(i=>i.id===id); cart.splice(idx,1); }
  saveCart(cart);
}

// clear cart
function clearCart(){ localStorage.removeItem(CART_KEY); updateCartCount(); openCart(); }

// checkout form
qs('#checkout-form').addEventListener('submit', function(ev){
  ev.preventDefault();
  const data = new FormData(this);
  const name = data.get('name');
  const phone = data.get('phone');
  const address = data.get('address');
  const note = data.get('note') || '';
  const cart = getCart();
  if(cart.length===0){ alert('السلة فارغة'); return; }
  // build message
  let text = `طلب من Secret Store%0Aالاسم: ${encodeURIComponent(name)}%0Aالهاتف: ${encodeURIComponent(phone)}%0Aالعنوان: ${encodeURIComponent(address)}%0A%0A`;
  text += 'الطلبات:%0A';
  cart.forEach(it=>{ text += `- ${encodeURIComponent(it.name)} x${it.qty} = ${encodeURIComponent(it.price)} جنيه%0A`; });
  text += `%0Aالمجموع: ${encodeURIComponent(cart.reduce((s,i)=>s+i.price*i.qty,0))} جنيه%0A`;
  if(note) text += `%0Aملاحظات: ${encodeURIComponent(note)}%0A`;
  // open whatsapp
  const wa = `https://wa.me/201555551102?text=${text}`;
  // clear cart after sending
  window.open(wa,'_blank');
  localStorage.removeItem(CART_KEY);
  updateCartCount();
  closeCart();
  alert('سيتم تحويلك إلى واتساب لإرسال الطلب. بعد الإرسال سيصلنا الطلب ونكلمك لتأكيد الشحن.');
});

// open/close helpers
function closeCart(){ qs('#cart-modal').setAttribute('aria-hidden','true'); }
updateCartCount();
